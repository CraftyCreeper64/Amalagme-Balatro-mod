
SMODS.Joker{ --Hand Mine
    key = "handmine",
    config = {
        extra = {
            myXmult = 1,
            odds = 2
        }
    },
    loc_txt = {
        ['name'] = 'Hand Mine',
        ['text'] = {
            [1] = '{C:green}#3# in 2{} chance for each discarded {C:attention}#2#{} to add {X:red,C:white}X0.2{} mult{}',
            [2] = 'Currently {X:red,C:white}X#1#{} Mult to this joker.',
            [3] = '{C:inactive}(Rank changes at end of round)',
            [4] = '(Warning! may not always behave as expected!){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["amalgame_amalgame_jokers"] = true, ["amalgame_amalgame_pack"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_amalgame_handmine') 
        return {vars = {card.ability.extra.myXmult, localize((G.GAME.current_round.targetRank_card or {}).rank or 'Ace', 'ranks'), new_numerator, new_denominator}}
    end,
    
    set_ability = function(self, card, initial)
        G.GAME.current_round.targetRank_card = { rank = 'Ace', id = 14 }
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if G.playing_cards then
                local valid_targetRank_cards = {}
                for _, v in ipairs(G.playing_cards) do
                    if not SMODS.has_no_rank(v) then
                        valid_targetRank_cards[#valid_targetRank_cards + 1] = v
                    end
                end
                if valid_targetRank_cards[1] then
                    local targetRank_card = pseudorandom_element(valid_targetRank_cards, pseudoseed('targetRank' .. G.GAME.round_resets.ante))
                    G.GAME.current_round.targetRank_card.rank = targetRank_card.base.value
                    G.GAME.current_round.targetRank_card.id = targetRank_card.base.id
                end
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.myXmult
            }
        end
        if context.discard  then
            if context.other_card:get_id() == 14 then
                if SMODS.pseudorandom_probability(card, 'group_0_aa2408fc', 1, card.ability.extra.odds, 'j_amalgame_handmine', false) then
                    SMODS.calculate_effect({func = function()
                        card.ability.extra.myXmult = (card.ability.extra.myXmult) + 0.2
                        return true
                    end}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Upgrade!", colour = G.C.GREEN})
                end
            end
        end
    end
}