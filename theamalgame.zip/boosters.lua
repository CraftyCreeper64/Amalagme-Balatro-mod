
SMODS.Booster {
    key = 'amalgame_pack',
    loc_txt = {
        name = "Amalgame Pack",
        text = {
            [1] = 'Choose {C:attention}1{} of up to {C:attention}2{} {X:planet,C:white}Amalgame{} cards',
            [2] = ''
        },
        group_name = "Amalgame Pack"
    },
    config = { extra = 2, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "amalgame_amalgame_pack",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "amalgame_amalgame_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("17898c"))
        ease_background_colour({ new_colour = HEX('17898c'), special_colour = HEX("0e5193"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
        end,
    }
    